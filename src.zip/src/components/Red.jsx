export default function Red() {
    return (
        <div className="Red">
        <h1>Red</h1>
        </div>
    )
}