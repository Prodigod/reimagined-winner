export default function Blue() {
    return (
        <div className="Blue">
            <h1>Red</h1>
        </div>
    )
}